# Music Player — Switch homebrew starter

An original, OPPO-Music-inspired local audio player starter for Nintendo Switch homebrew.
It is **not** an Android APK converter and does not include OPPO proprietary code, branding,
or artwork.

## Current prototype features
- Scans `sdmc:/music` for MP3, WAV, OGG and FLAC files (top-level folder only).
- Basic playlist, play/pause, previous/next, and rescan controls.
- Dark player interface.
- NRO build target using devkitPro/libnx and SDL2 portlibs.

## Important: this is source code, not a ready-to-install NRO
This environment does not have devkitPro/libnx or the Switch SDL2 portlibs installed,
so an `.nro` binary cannot honestly be claimed or tested here. Build it on a devkitPro
environment with the required Switch portlibs.

## Build requirements
- devkitPro with `switch-dev`, `libnx`
- Switch-target SDL2, SDL2_mixer, SDL2_ttf portlibs
- SDL_mixer built with MP3 support (e.g. mpg123)

Then run:
```sh
make
```
The output should be `oppomusic.nro` if all dependencies and linker flags are configured.

## Install
1. Copy `oppomusic.nro` to `sdmc:/switch/oppomusic/oppomusic.nro`.
2. Create `sdmc:/music/` and copy MP3 files into it.
3. Optional font: copy a freely licensed TTF font to
   `sdmc:/switch/oppomusic/font.ttf`.
4. Launch from the Homebrew Menu.

## Controls
- A / Enter: play or pause
- L / Left: previous track
- R / Right: next track
- Up / Down: select track
- Y: rescan `sdmc:/music`
- B / Escape: exit

## Sleep-mode limitation
A homebrew application cannot keep executing ordinary audio playback while the Switch is
in a full system suspend state: the CPU/application is suspended. Screen-off without
entering full suspend is a different state. This prototype does not implement or promise
audio during full Sleep Mode. A reliable solution would require platform-level support
that ordinary SDL playback cannot provide.

## Compatibility
The source is a starting prototype, not yet verified on Atmosphère 1.12.1 / firmware 23.0.1.
Test on a backed-up SD card and do not install sysmodules as part of this prototype.
