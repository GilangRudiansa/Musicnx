#include <switch.h>
#include <SDL.h>
#include <SDL_mixer.h>
#include <SDL_ttf.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>

#define MUSIC_DIR "sdmc:/music"
#define MAX_TRACKS 512
#define W 1280
#define H 720

static char tracks[MAX_TRACKS][512];
static int track_count = 0, selected = 0;
static Mix_Music *music = NULL;
static TTF_Font *font = NULL;
static int paused = 0;
static SDL_Window *window = NULL;
static SDL_Renderer *renderer = NULL;

static int is_audio(const char *n) {
    const char *dot = strrchr(n, '.');
    if (!dot) return 0;
    return !strcasecmp(dot, ".mp3") || !strcasecmp(dot, ".wav") ||
           !strcasecmp(dot, ".ogg") || !strcasecmp(dot, ".flac");
}

static void scan_music(void) {
    DIR *d = opendir(MUSIC_DIR);
    struct dirent *e;
    track_count = 0;
    if (!d) return;
    while ((e = readdir(d)) && track_count < MAX_TRACKS) {
        if (e->d_name[0] == '.' || !is_audio(e->d_name)) continue;
        snprintf(tracks[track_count], sizeof(tracks[track_count]),
                 "%s/%s", MUSIC_DIR, e->d_name);
        track_count++;
    }
    closedir(d);
}

static void stop_music(void) {
    if (music) {
        Mix_HaltMusic();
        Mix_FreeMusic(music);
        music = NULL;
    }
    paused = 0;
}

static void play_track(int index) {
    if (track_count == 0) return;
    if (index < 0) index = track_count - 1;
    if (index >= track_count) index = 0;
    selected = index;
    stop_music();
    music = Mix_LoadMUS(tracks[selected]);
    if (music) Mix_PlayMusic(music, 0);
}

static void draw_text(const char *s, int x, int y, SDL_Color c) {
    if (!font || !s) return;
    SDL_Surface *surf = TTF_RenderUTF8_Blended(font, s, c);
    if (!surf) return;
    SDL_Texture *tex = SDL_CreateTextureFromSurface(renderer, surf);
    SDL_Rect r = {x, y, surf->w, surf->h};
    SDL_RenderCopy(renderer, tex, NULL, &r);
    SDL_DestroyTexture(tex);
    SDL_FreeSurface(surf);
}

static void fill(int x, int y, int w, int h, Uint8 r, Uint8 g, Uint8 b) {
    SDL_Rect q = {x,y,w,h};
    SDL_SetRenderDrawColor(renderer, r,g,b,255);
    SDL_RenderFillRect(renderer, &q);
}

static const char *base_name(const char *p) {
    const char *s = strrchr(p, '/');
    return s ? s + 1 : p;
}

static void render(void) {
    SDL_Color white = {245,245,248,255}, muted = {155,160,174,255};
    SDL_Color accent = {91,112,235,255};
    SDL_SetRenderDrawColor(renderer, 17,19,28,255);
    SDL_RenderClear(renderer);

    fill(0,0,300,H,23,26,38);
    draw_text("MUSIC PLAYER", 34, 34, white);
    draw_text("SWITCH EDITION", 34, 68, muted);
    fill(32,112,236,2,91,112,235);
    draw_text("LIBRARY", 34, 145, accent);
    draw_text("Local music", 34, 190, white);
    draw_text("Folder: sdmc:/music", 34, 232, muted);
    draw_text("Supported: MP3 WAV OGG FLAC", 34, 264, muted);

    draw_text("NOW PLAYING", 350, 54, accent);
    if (track_count && selected < track_count) {
        draw_text(base_name(tracks[selected]), 350, 104, white);
    } else {
        draw_text("No music found", 350, 104, white);
    }
    fill(350,160,850,2,52,57,72);
    draw_text("A  Play / Pause", 350, 190, white);
    draw_text("L / R  Previous / Next", 350, 230, white);
    draw_text("UP / DOWN  Select track", 350, 270, white);
    draw_text("Y  Rescan folder", 350, 310, white);
    draw_text("B  Exit", 350, 350, muted);

    draw_text("PLAYLIST", 350, 420, accent);
    int start = selected > 7 ? selected - 7 : 0;
    for (int i = start; i < track_count && i < start + 9; i++) {
        int y = 462 + (i-start)*26;
        if (i == selected) fill(338,y-4,870,25,42,48,70);
        draw_text(base_name(tracks[i]), 356, y, i == selected ? white : muted);
    }
    if (paused) draw_text("PAUSED", 1100, 54, muted);
    else if (Mix_PlayingMusic()) draw_text("PLAYING", 1100, 54, accent);
    SDL_RenderPresent(renderer);
}

int main(int argc, char **argv) {
    (void)argc; (void)argv;
    romfsInit();
    chdir("sdmc:/");
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    TTF_Init();
    Mix_Init(MIX_INIT_MP3 | MIX_INIT_OGG | MIX_INIT_FLAC);
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        // The UI can still open; playback will report unavailable.
    }

    window = SDL_CreateWindow("Music Player", SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED, W, H, SDL_WINDOW_SHOWN);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED |
        SDL_RENDERER_PRESENTVSYNC);
    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);

    font = TTF_OpenFont("sdmc:/switch/oppomusic/font.ttf", 22);
    if (!font) font = TTF_OpenFont("romfs:/font.ttf", 22);

    scan_music();
    padConfigureInput(1, HidNpadStyleSet_NpadStandard);
    PadState pad;
    padInitializeDefault(&pad);
    int running = 1;
    while (running && appletMainLoop()) {
        SDL_Event ev;
        while (SDL_PollEvent(&ev)) {
            if (ev.type == SDL_QUIT) running = 0;
        }
        padUpdate(&pad);
        u64 keys = padGetButtonsDown(&pad);
        if (keys & KEY_B) running = 0;
        if ((keys & KEY_DUP) && track_count) selected = (selected + track_count - 1) % track_count;
        if ((keys & KEY_DDOWN) && track_count) selected = (selected + 1) % track_count;
        if (keys & KEY_A) {
            if (!music) play_track(selected);
            else if (Mix_PausedMusic()) { Mix_ResumeMusic(); paused = 0; }
            else if (Mix_PlayingMusic()) { Mix_PauseMusic(); paused = 1; }
            else play_track(selected);
        }
        if (keys & KEY_L) play_track(selected - 1);
        if (keys & KEY_R) play_track(selected + 1);
        if (keys & KEY_Y) scan_music();
        render();
        SDL_Delay(16);
    }

    stop_music();
    if (font) TTF_CloseFont(font);
    if (renderer) SDL_DestroyRenderer(renderer);
    if (window) SDL_DestroyWindow(window);
    Mix_CloseAudio();
    Mix_Quit();
    TTF_Quit();
    SDL_Quit();
    romfsExit();
    return 0;
}
